const data = {
    users: [
        {
            name: 'Al hasan',
            email: 'alhasan@gmail.com',
            password: '123456',
            phone: '01771341287',
            address: 'Mohammadpur, Dhaka'
        },
        {
            name: 'Juwel',
            email: 'juwel@gmail.com',
            password: '123456',
            phone: '01905869919',
            address: 'Mohammadpur, Dhaka'
        },
        {
            name: 'Mohammad',
            email: 'md@gmail.com',
            password: '123456',
            phone: '01905869111',
            address: 'Badda, Dhaka'
        }
    ]
}
module.exports=data;
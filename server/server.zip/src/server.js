const express= require("express");
const morgan= require("morgan");
const xss= require('xss-clean');
const createError = require('http-errors');
const bodyParser = require('body-parser');
const rateLimit= require('express-rate-limit');
const { serverPort } = require("./secret");
const userRouter = require("./routers/userRouter");
const connectDB = require("./config/db");
const seedRouter = require("./routers/seedRouter");
const { errorResponse } = require("./controllers/responseController");

const app= express();
const rateLimiter= rateLimit({
    windowMs: 1*60*1000, // 1 minit
    max: 5,
    message: "Too many requests from this IP. Please try again later."
});
app.use(bodyParser.json());
app.use(bodyParser.urlencoded({ extended: true }));
app.use(morgan('dev'));
app.use(xss());

const isLoggedIn = (req,res,next) =>{
    const login= true;
    if(login){
        req.body.id=102;
    next()
    }else{
    res.status(401).json({message: "Please login first"});
    }
   

}

app.use('/api/users',userRouter);
app.use('/api/seed',seedRouter);



app.use((req, res, next) => {
    next(createError(404, 'route not found'));
  });
  
  // all the errors will come here in the end from all the routes
  app.use((err, req, res, next) => {      
      return errorResponse(res,{
        statusCode: err.status,
        message: err.message
      });

    });

app.listen(serverPort, ()=>{
console.log(`server is running on the port: ${serverPort}`);
connectDB();
});